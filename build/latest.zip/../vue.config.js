const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  assetsDir:'./',
  transpileDependencies: true,
  publicPath: ''
})
