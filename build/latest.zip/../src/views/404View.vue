<template>
    <div>
        <h1>未找到您访问的路由记录</h1>
        <p>检查您是否拼错URL?</p>
        <p>检查资源是否存在?</p>
        <p>若实在有问题,请与管理员联系!</p>

        <router-link to="/">
            <el-link type="primary">返回主页</el-link>
        </router-link>

    </div>
</template>

<script>
export default {

}
</script>

<style>
</style>