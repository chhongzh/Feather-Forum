<template>
    <el-card>
        <div class="block-body block-row">
            <p>此页面介绍本站使用 Cookie 做什么。如果您继续使用本站,则表示同意我们使用 Cookie。</p>

            <h3 class="textHeading">Cookie 是什么</h3>
            <p>Cookie 是由您访问的网站服务器端生成,发送给您的浏览器(例如 Internet
                Explorer、Firefox),这些小文件储存在您的计算机上。允许您浏览的网站保留访问信息,例如您的偏好设置、历史记录和保持登录状态。</p>

            <p>Cookie 即可短时间内保存在您的计算机上(只有当您的浏览器打开时),也长时间保存(一年)。如果网站不设置 Cookie ,我们将无法登陆。</p>

            <h3 class="textHeading">我们使用 Cookie 做什么</h3>
            <p>本站 Cookie 作用：</p>
            <ul>
                <li>注册和保持您的偏好设置。确保您可以随时登录和保持您对网站语言或外观的设置。</li>
                <li>分析。使我们能够确定访问本站的目标人群,并进行改进。</li>
                <li>广告或第三方 Cookie。如果此网站显示广告,广告商通过 Cookie 来了解广告效果。这些 Cookie 通常由第三方管理,因此本站无法对其进行读取或修改。</li>
                <li>第三方 Cookie (Facebook 和 Twitter 分享)。这些 Cookie 通常由第三方独立管理,因此本站无法对其进行访问。</li>
            </ul>

            <h3 class="textHeading">移除/关闭 Cookie</h3>
            <p>在您的浏览器 选项/设置 中管理您的 Cookie 和 Cookie 设置。流行的浏览器设置指南如下：</p>
            <ul>
                <li>
                    <el-link target="_blank"
                        href="http://windows.microsoft.com/en-US/internet-explorer/delete-manage-cookies">Internet
                        Explorer</el-link>
                </li>
                <li>
                    <el-link target="_blank"
                        href="http://support.mozilla.org/kb/cookies-information-websites-store-on-your-computer">
                        Firefox</el-link>
                </li>
                <li>
                    <el-link target="_blank" href="https://support.google.com/chrome/answer/95647?hl=en">Chrome
                    </el-link>
                </li>
                <li>
                    <el-link target="_blank" href="http://support.apple.com/kb/PH17191">Safari</el-link>
                </li>
                <li>
                    <el-link target="_blank" href="http://www.opera.com/help/tutorials/security/privacy/">Opera
                    </el-link>
                </li>
            </ul>
        </div>
    </el-card>
</template>

<script>
export default {

}
</script>

<style>
</style>