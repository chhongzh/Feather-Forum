<template>
    <el-card>
        <p>选择一个项目</p>
    </el-card>
</template>

<script>
export default {
    name: 'HelpDefault'
}
</script>

<style>
</style>