# ---------------------------------------------------------------------------
class Config(object):
    UseDebugMode = True
    ServerPort = 14524
    Version = [1, 23, 2]
    SecretKey = 'Feather-Forum Demo on Debug Mode !'
# ---------------------------------------------------------------------------
