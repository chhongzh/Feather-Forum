# ---------------------------------------------------------------------------
class Code():
    REQUEST_BAD_QUERY = 1020
    REQUEST_USER_REG_ERROR = 1010
    REQUEST_OK = 200
    REQUEST_USER_LOG_ERROR = 1011
    REQUEST_BAD_AUTHKEY = 1030
    REQUEST_ERROR = 1000
    SERVER_ERROR = 500
# ---------------------------------------------------------------------------
