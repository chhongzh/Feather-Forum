# ---------------------------------------------------------------------------
from flask import Blueprint, request
from lib.request import buildRequest
from lib.request import request_parse
from lib.code import Code
from time import time
from lib.database import getConfigByKey
from lib import share
from lib.authkey import validate_authkey
from math import ceil
from time import time
from hashlib import sha256
from uuid import uuid4
from lib.database import query
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
lock = share.lock
c = share.c
conn = share.conn
log = share.log
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
blueprint = Blueprint('user', __name__, url_prefix='/api/user')
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
@blueprint.route("/register", methods=["POST"])
def Register():
    data = request_parse(request)
    if (data.get('name', None) is None or
        data.get('pw', None) is None or
        data.get('email', None) is None
        ):
        return buildRequest(Code.REQUEST_BAD_QUERY, "用户名或密码或email为空")
    for _ in query("SELECT name FROM user WHERE name=(?)", [data.get('name')]):
        return buildRequest(Code.REQUEST_USER_REG_ERROR, "用户名已存在")
    name = data.get('name').replace("'", "''").replace('"', '""')
    pw = data.get('pw').replace("'", "''").replace('"', '""')
    email = data.get('email').replace("'", "''").replace('"', '""')
    query(f"""
                INSERT INTO user (name,password,email,time,last,authkey,uuid)
                VALUES ((?),(?),(?),(?),0,Null,(?))
            """
          [name,
           sha256(bytes(pw, encoding='utf8')).hexdigest(),
           email,
           int(time()),
           uuid4()
           ])
    conn.commit()
    return buildRequest(Code.REQUEST_OK, "注册成功")

# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
@blueprint.route("/login", methods=["POST"])
def Login():
    data = request_parse(request)
    if (data.get('name', None) is None or
        data.get('pw', None) is None
        ):
        return buildRequest(Code.REQUEST_BAD_QUERY, "用户名或密码为空")
    if (lock.acquire()):
        for dname, dpw, duid, demail, dcoin, dtime, dlast, dauthkey, duuid, davrtar in c.execute(f"""SELECT * FROM user WHERE name='{data.get('name')}'"""):
            if (dpw == sha256(bytes(data.get('pw'), encoding='utf8')).hexdigest()):
                authkey = str(uuid4())
                c.execute(f"""
                UPDATE user SET "authkey"='{authkey}',"last"={int(time())} WHERE "name"='{dname}' and "password"='{dpw}'
                """)
                conn.commit()
                lock.release()
                return buildRequest(Code.REQUEST_OK, "登录成功", authkey=authkey)
            else:
                lock.release()
                return buildRequest(Code.REQUEST_USER_LOG_ERROR, "登录失败,用户名或密码错误!")
        lock.release()
        return buildRequest(Code.REQUEST_USER_LOG_ERROR, "登录失败,用户名或密码错误!")
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
@blueprint.route("/info", methods=["POST"])
def Info():
    data = request_parse(request)
    authkey = data.get('authkey')
    if (authkey is None or '"' in authkey or "'" in authkey or len(authkey) > 36 or len(authkey) < 36 or '-' not in authkey):
        return buildRequest(Code.REQUEST_BAD_QUERY, "无效的AuthKey")
    ak = validate_authkey(authkey)
    if (ak):

        return buildRequest(Code.REQUEST_OK, "有效的AuthKey",
                            name=ak["name"],
                            uid=ak["uid"],
                            email=ak["email"],
                            coin=ak["coin"],
                            regtime=ak["regtime"],
                            last=ak["last"],
                            uuid=ak["uuid"],
                            avartar=ak["avartar"],
                            authkey=True
                            )
    else:
        return buildRequest(Code.REQUEST_BAD_AUTHKEY, "不存在或过期的AuthKey", authkey=False)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
@blueprint.route('/info/<uid>')
def UserPublicInfo(uid: str):
    if (not uid.isdigit()):
        return buildRequest(Code.REQUEST_BAD_QUERY, 'uid必须为数字')
    uid = int(uid)
    if (uid == 0 or uid < 0):
        return buildRequest(Code.REQUEST_BAD_QUERY, 'uid不合法')

    if (lock.acquire()):
        for dname, _, dlast, dtime, duid, duuid, davartar, dcoin, demail, _ in c.execute(f"""SELECT * FROM user WHERE uid='{uid}'"""):
            lock.release()
            return buildRequest(Code.REQUEST_OK, "查询成功",
                                name=dname,
                                uid=duid,
                                email=demail,
                                coin=dcoin,
                                time=dtime,
                                last=dlast,
                                uuid=duuid,
                                avartar=davartar
                                )

        lock.release()
        return buildRequest(Code.REQUEST_BAD_QUERY, 'uid未找到')
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
@blueprint.route("/list", methods=["GET"])
def ListUser():
    data = request_parse(request)
    p = int(getConfigByKey('itemLimit'))
    page = p * \
        data.get('page', default=0, type=int)
    obj = []
    if (lock.acquire()):
        for dname, duid, dcoin, dtime, dlast, davartar in c.execute(f"SELECT name,uid,coin,time,last,avartar FROM user LIMIT {p} OFFSET {page}"):
            obj1 = {}
            obj1.update({
                "name": dname,
                "uid": duid,
                "coin": dcoin,
                "time": dtime,
                "last": dlast,
                "avartar": davartar
            })
            obj.append(obj1)
        lock.release()
    last = False
    if (len(obj) < p):
        last = True
    return buildRequest(Code.REQUEST_OK, "查询成功", list=obj, last=last)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
@blueprint.route("/top")
def TopUser():
    obj = []
    if (lock.acquire()):
        for dname, duid, dcoin, dtime, dlast, davartar in c.execute("""
            SELECT name,uid,coin,time,last,avartar FROM user ORDER BY uid DESC LIMIT 5
        """):
            obj1 = {}
            obj1.update({
                "name": dname,
                "uid": duid,
                "coin": dcoin,
                "time": dtime,
                "last": dlast,
                "avartar": davartar
            })
            obj.append(obj1)
    lock.release()
    return buildRequest(Code.REQUEST_OK, "查询成功", list=obj)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
@blueprint.route("/count", methods=["GET"])
def CountUser():
    if (lock.acquire()):
        for i in c.execute("SELECT count(*) FROM user"):
            lock.release()

            return buildRequest(Code.REQUEST_OK, "查询成功", count=i[0])
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
@blueprint.route("/page")
def PageUser():
    total = 0
    if (lock.acquire()):
        for i in c.execute("""
        SELECT count(*) FROM user
        """):
            total = i[0]
        lock.release()
    page = int(getConfigByKey('itemLimit'))
    total = ceil(total/page)

    return buildRequest(Code.REQUEST_OK, msg="查询成功", page=total-1)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------


@blueprint.route("/follow", methods=["POST"])
def FollowUser():
    data = request_parse(request)
    authkey = data.get('authkey', None)
    tofollow = data.get('to', None)
    if (authkey is None or tofollow is None or tofollow <= 0):
        return buildRequest(Code.REQUEST_BAD_QUERY, "参数错误")
    ak = validate_authkey(authkey)
    if (ak is None):
        return buildRequest(Code.REQUEST_BAD_AUTHKEY, '无法验证authkey')
    if (lock.acquire()):
        for _ in c.execute('''SELECT * FROM follow WHERE "from"={} and "to"={}
        '''.format(ak['uid'], tofollow)):
            lock.release()
            return buildRequest(Code.REQUEST_ERROR, "你已经关注了!")
        c.execute("""INSERT INTO follow ('from','to','time') VALUES ({},{},{})""".format(
            ak['uid'],
            tofollow,
            int(time())
        ))
        conn.commit()
        lock.release()
        return buildRequest(Code.REQUEST_OK, "关注成功!")


# ---------------------------------------------------------------------------
